$(function() {

	$(window).on('load',function () {
	
		/*-------------------------------------
		Masonry
		-------------------------------------*/
		$(function(){

			var section = $('.alx-layout-isotope');


			section.imagesLoaded().done(function(){
				section.isotope({
					itemSelector: '.alx-isotope-item',
					percentPosition: true,
					masonry: {
						columnWidth: '.alx-isotope-item'
					},
					layoutMode: 'packery',
					transitionDuration: '0.8s',

					
				});
			});

			$(window).on('resize', function() {
				section.isotope();
			}).trigger('resize');

		});
	});

	$(document).ready(function(){
		$('#alx-slider-main-four').alx_slider_main_four();
		/*-------------------------------------
		Portfolio control
		-------------------------------------*/
		$(function() {
			if ($(".alx-portfolio-control").length) {
				$('.alx-portfolio-control li').on('click', function () {

					var filter = $(this).attr('data-filter');
					$('.alx-portfolio-control li').removeClass('alx-active');
					$(this).addClass('alx-active');


					$('.alx-layout-isotope').isotope({
						filter: filter,
						masonry: {
							transitionDuration: '0.8s',
							percentPosition: true,
						}

					});
					return false;
				});
			}
		});


	})


	/*-------------------------------------
	 	MatchHeight
	 -------------------------------------*/
	 if( $( window ).width() < 992 ) {
		$('.alx-slider-main-height').matchHeight({
			property: 'height'
		});
	 }

	 $('.alx-match-height').matchHeight({
		property: 'height'
	});


	 /*-------------------------------------
		 Add active class to current menu
	 -------------------------------------*/
	$(function () {
		var url = window.location.pathname,
			urlRegExp = new RegExp(url.replace(/\/$/, '') + "$");
		$('.alx-menu-top > li > a').each(function () {
			if (urlRegExp.test(this.href.replace(/\/$/, ''))) {
				$(this).parent().addClass('alx-active');
			}
		});
	});


	$(document).on('click', 'a[href^="#"]:not(.open-popup-link, .ui-tabs-anchor)', function(e) {

		var pathname = window.location.href.split('#')[0];

			var $this = $(this),
				link = $this.attr('href');
			$this.attr('href', pathname + link);


        var id = $(this).attr('href');
        // target element
        var $link = $(link);
        if ($link.length === 0) {
            return;
        }
		e.preventDefault();
		var pos = $link.offset().top;
		$('html, body').stop().animate({
			scrollTop: pos
		}, {
			duration: 1000,
			specialEasing: {
				width: "linear",
				height: "easeInOutCubic"
			}
		});
    });



	// $(window).on('resize', function() {
	// 	alx_slider_main_height();
	// }).trigger('resize');

	// function alx_slider_main_height() {
	// 	$('.alx-slider-main').each(function() {
	// 		var height = $(this).find('.alx-slider-main-content').outerHeight(),
	// 			nav = $(this).find('.alx-slider-main-image');


	// 			nav.css('height', height);



	// 	});
	// }
	// alx_slider_main_height();

	/*-------------------------------------
	 	Burger
	 -------------------------------------*/
	 $('.alx-burger').each(function(){
		$(this).on('click', function(e){
			e.preventDefault();
			$(this).toggleClass('on');
		})
	});


	/*-------------------------------------
	 	Side Bar
	 -------------------------------------*/
	$(function() {

		var $toggleSidebar = $("#alx-sidebar-burger"),
			$body = $('body'),
			$sidebar = $(".alx-aside-sidebar"),
			$sidebarOverlay = $(".alx-aside-sidebar__overlay"),
			$sidebarClose = $('#alx-sidebar').children(".alx-burger"),
			$sedibarOpened = false;

		function alx_sidebar_close(){
			$body.removeClass('alx-aside-sidebar__openoverlay');
			$sidebar.removeClass('alx-aside-sidebar__open');
			$toggleSidebar.removeClass('on');
		}

		$toggleSidebar.on('click', function(e) {
			if(!$sedibarOpened){
				e.preventDefault();
				$body.toggleClass('alx-aside-sidebar__openoverlay');
				$sidebar.toggleClass('alx-aside-sidebar__open');
			}
			$sedibarOpened = true;
			// return false;
		});

		$sidebarOverlay.on('click', function(e){
			if($sedibarOpened) {
				e.preventDefault();
				alx_sidebar_close();
			}
			$sedibarOpened = false;
		});

		$sidebarClose.on('click', function(e) {
			if($sedibarOpened) {
				e.preventDefault();
				alx_sidebar_close();
				$sedibarOpened = false;
			}
		});

	});

	$(function(){
		$menu = $('.alx-sidebar-menu'),
		$menu.find('li').each(function(){
			var haschilditem = false,
				ths = $(this);


			if(ths.find("ul").length){
				ths.addClass('alx-menu-item-has-children');
				haschilditem = true;
			}
			if(haschilditem){
				ths.children('a').on('click', function(e) {
					e.preventDefault();
					ths.toggleClass('alx-menu-sub-active').next('ul').slideUp(250);
					return false;
				});
			}
		});
	})

	/*-------------------------------------
	Accordion
	-------------------------------------*/
	$('.alx-accordion:nth-child(1n)').accordion({
		heightStyle: 'content',
		active: true

	});

		/*-------------------------------------
		Skills
	-------------------------------------*/
	$('.alx-progress').each(function(){
		var $ths_out = $(this).find('.alx-progress__body'),
			$ths_in = $(this).find('.alx-progress__bar');


		$ths_in.waypoint(function (dir) {
			if (dir === "down") {
				$ths_in.animate({
					width:$ths_in.attr('data-progress')
				},1500);
			}
			else {
				$ths_in.css('width', '0');
			}
			}, {
				offset: "90%"
			});
	});


	/*-------------------------------------
		Mobile menu - full screen menu
	-------------------------------------*/
	$(function() {

		// $('ul.sf-menu').find('li').clone().appendTo('.al-mobile-menu > ul');

		var $menu = $('.alx-mobile-menu'),
			$fnToggle = $('.alx-burger-menu'),
			$body = $('body'),
			$logo = $('.alx-logo');


			$menu.find('li').each(function(){
				var haschilditem = false,
					ths = $(this);


				if(ths.find("ul").length){
					ths.addClass('alx-menu-item-has-children');
					haschilditem = true;
				}
				if(haschilditem){
					ths.children('a').on('click', function(e) {
						e.preventDefault();
						ths.toggleClass('alx-menu-sub-active').next('ul').slideUp(250);
						return false;
					});
				}
			});


			var fnOpen = false;

			var fnToggleFunc = function() {
				fnOpen = !fnOpen;
				$menu.stop().fadeToggle(500);
				$menu.toggleClass("active");
				$fnToggle.toggleClass('on-active');
				$logo.toggleClass('on');
				$body.toggleClass('alx-mobile-menu-active');
				$logo.toggleClass('al-dark-logo');
				return false;
			};

			$fnToggle.on('click', fnToggleFunc);

			$menu.on('click', function(){
				fnToggleFunc();
				$fnToggle.removeClass('on');
				return true;
			});
	});

	/*-------------------------------------
	 	Services Slides
	 -------------------------------------*/
	 $.fn.alx_team_slider = function() {
		$(this).each(function() {
			var $dots = $(this).find('.alx-dots-control');
			var $arrows = $(this).find('.alx-slider-main-control-arrows');
			var $next = $arrows.children(".alx-slider-main-control-next");
			var $prev = $arrows.children(".alx-slider-main-control-prev");
			var $slider_nav = $(this).find('.alx-team-nav-slider').children('.alx-team-nav-slides');

			var $slick_slider = $(this).find(".alx-team-slides").not('.slick-initialized');

			$slick_slider.slick({
				dots: false,
				fade: true,
				appendDots: $dots,
				arrows: true,
				dotsClass: 'dots',
				autoplay: false,
				autoplaySpeed: 8000,
				autoHeight: false,
				infinite: true,
				cssEase: 'linear',
				adaptiveHeight: true,
				prevArrow: $prev,
				nextArrow: $next,
				asNavFor: $slider_nav,
				customPaging : function(slider, i) {
				var thumb = $(slider.$slides[i]).data(),
					slides = i + 1;
					if( i < 9 ){
						return '<button>0'+slides+'</button>';
					}else{
						return '<button>'+slides+'</button>';
					}
				},
				responsive: [
					{
						breakpoint: 992,
							settings: {
							arrows: false,
							// dots: true
						}
					},
				]
			});

			$slider_nav.slick({
				slidesToShow: 5,
				arrows: false,
				// infinite: true,
				slidesToScroll: 1,
				asNavFor: $slick_slider,
				dots: false,
				centerMode: true,
				focusOnSelect: true,
				responsive: [
					{
						breakpoint: 1400,
							settings: {
							slidesToShow: 3,
						}
					},
					{
						breakpoint: 992,
							settings: {
							slidesToShow: 2,
							centerMode: true,

						}
					},
					{
						breakpoint: 655,
							settings: {
							slidesToShow: 1,
						}
					},
				]
			  });
		});
	};

	$('.alx-team-wrap-slider').alx_team_slider();



	/*-------------------------------------
	 	Services Slides
	 -------------------------------------*/
	 $.fn.alx_services_slider = function() {
		$(this).each(function() {
			var $dots = $(this).find('.alx-dots-control');
			var $arrows = $(this).find('.alx-slider-main-control-arrows');
			var $next = $arrows.children(".alx-slider-main-control-next");
			var $prev = $arrows.children(".alx-slider-main-control-prev");
			var $slider_nav = $(this).find('.alx-services-slider-nav');

			var $slick_slider = $(this).children(".alx-services-slider-slides").not('.slick-initialized');

			$slick_slider.slick({
				dots: true,
				fade: true,
				appendDots: $dots,
				dotsClass: 'dots',
				autoplay: false,
				autoplaySpeed: 8000,
				autoHeight: false,
				infinite: true,
				cssEase: 'linear',
				adaptiveHeight: true,
				prevArrow: $prev,
				nextArrow: $next,
				asNavFor: $slider_nav,
				customPaging : function(slider, i) {
				var thumb = $(slider.$slides[i]).data(),
					slides = i + 1;
					if( i < 9 ){
						return '<button>0'+slides+'</button>';
					}else{
						return '<button>'+slides+'</button>';
					}
				},
				// responsive: [
				// 	{
				// 		breakpoint: 992,
				// 			settings: {
				// 			arrows: false,
				// 			dots: true
				// 		}
				// 	},
				// ]
			});
			$slider_nav.slick({
				slidesToShow: 4,
				arrows: false,
				infinite: true,
				slidesToScroll: 1,
				asNavFor: $slick_slider,
				dots: false,
				// centerMode: true,
				// focusOnSelect: true,
				responsive: [
					{
						breakpoint: 400,
							settings: {

							slidesToShow: 2,

						}
					},
				]
			  });
		});
	};

	$('#alx-services-slider').alx_services_slider();



	/*-------------------------------------
	 Top menu - Superfish
	 -------------------------------------*/
	 $('ul.alx-menu-top').superfish({
		delay: 300,
		speed: 200,
		animation:     ({opacity:'show',  height:'show'}),
		animationOut:  ({opacity:'hide', height:'hide'}),
		cssArrows: true,
		disableHI: false,
		easing: 'fadeInUp',
		touchMove: false,
		swipe: false
	});


	

	$('.alx-img-gallery').magnificPopup({
		type:'image',
		mainClass: 'mfp-fade',
		gallery:{enabled:true}
	});




	/*-------------------------------------
		Mobile menu - full screen menu
	-------------------------------------*/
	$(function() {

		$('ul.sf-menu').find('li').clone().appendTo('.al-mobile-menu > ul');

		var $menu = $('.al-mobile-menu'),
			$body = $('body'),
			$fn = $('.al-mobile-menu'),
			$fnToggle = $('.toggle-mnu'),
			$logo = $('.al-logo'),
			$window = $(window);

			$menu.find('.menu-item-has-children > a').on('click', function(e) {
				e.preventDefault();
				if ($(this).next('ul').is(':visible')) {
					$(this).removeClass('sub-active').next('ul').slideUp(250);
				} else {
					$(this).addClass('sub-active').next('ul').slideToggle(250);
				}
			});

			var fnOpen = false;

			var fnToggleFunc = function() {
				fnOpen = !fnOpen;
				$fn.stop().fadeToggle(500);
				$fn.toggleClass("active");
				$('.toggle-mnu').toggleClass('on');
				$logo.toggleClass('on');
				$logo.toggleClass('al-dark-logo');
				return false;
			};

			$fnToggle.on('click', fnToggleFunc);

			$(document).on('keyup', function(e) {
				if (e.keyCode == 27 && fnOpen) {
					fnToggleFunc();
				}

			});

			// $fn.find('li > a').one('click', function() {
			// 	fnToggleFunc();
			// 	return true;
			// });

			$menu.on('click', function(){
				fnToggleFunc();
				return true;
			});

			$('.inner-wrap, .fullscreen-menu-toggle').on('click', function(e){
				e.stopPropagation();
			});
	});

	/*-------------------------------------
	 Background function
	 -------------------------------------*/
	$.fn.alx_background_image = function() {
		$(this).each(function() {
			var url = $(this).attr('data-image');
			if(url){
				$(this).css('background-image', 'url(' + url + ')');
			}
		});
	};
	$('.alx-bg-img').alx_background_image();

	/*-------------------------------------
		Tabs
	-------------------------------------*/
	$( ".alx-tabs:nth-child(1n)" ).tabs({
		hide: 'fade',
		show: 'fade'
	});

	/*-------------------------------------
		Slider
	-------------------------------------*/

	$.fn.alx_slider_main = function() {
		$(this).each(function() {
			var $dots = $(this).find('.alx-dots-control'),
				$arrows = $(this).find('.alx-slider-main-control-arrows'),
				$next = $arrows.children(".alx-slider-main-control-next"),
				$prev = $arrows.children(".alx-slider-main-control-prev"),
				$slick_slider = $(this).children(".alx-slider-main-slides"),
				$alx_fade = true;
				$alx_vertical = $(this).hasClass('alx-slider-main__second');

				if($alx_vertical == true){
					$alx_fade = false;
				}



			$slick_slider.not('.slick-initialized').slick({
				dots: true,
				fade: $alx_fade,
				vertical: $alx_vertical,
				appendDots: $dots,
				dotsClass: 'dots',
				autoplay: false,
				autoplaySpeed: 8000,
				autoHeight: false,
				infinite: true,
				cssEase: 'linear',
				adaptiveHeight: true,

				prevArrow: $prev,
				nextArrow: $next,
				customPaging : function(slider, i, event) {
					var thumb = $(slider.$slides[i]).data(),
						count = slider.$slides.length,

					slides = i + 1;

					if($alx_vertical){
						if( i < 9 ){
							return '<button data-tooltip="'+slides+'/'+count+'" flow="left"><span>0'+slides+'</span></button>';
						}else{
							return '<button data-tooltip="'+slides+'/'+count+'" flow="left"><span>'+slides+'</span></button>';
						}
					}else{
						if( i < 9 ){
							return '<button><span>0'+slides+'</span></button>';
						}else{
							return '<button><span>'+slides+'</span></button>';
						}
					}

				},
				responsive: [
					{
						breakpoint: 991,
							settings: {
							vertical: false,

						}
					},
				]

			});

		});
	};

	$('#alx-slider-main').alx_slider_main();

	/*-------------------------------------
	 	Zoom
	 -------------------------------------*/
	 $('.alx-zoom').zoom();

	 /*-------------------------------------
	 	Slider four
	 -------------------------------------*/

	 $.fn.alx_slider_main_four = function() {
		$(this).each(function() {
			var $dots = $(this).find('.alx-dots-control'),
				$arrows = $(this).find('.alx-slider-main-control-arrows'),
				$next = $arrows.children(".alx-slider-main-control-next"),
				$prev = $arrows.children(".alx-slider-main-control-prev"),
				$slick_slider = $(this).find(".alx-slider-main-four-slides"),
				$slider_nav = $(this).find('.alx-slider-main__four-posts');

			



			$slick_slider.not('.slick-initialized').slick({
				dots: false,
				// fade: true,
			
				appendDots: $dots,
				dotsClass: 'dots',
				autoplay: false,
				autoplaySpeed: 8000,
				autoHeight: false,
				infinite: true,
				cssEase: 'linear',
				adaptiveHeight: true,
				prevArrow: $prev,
				nextArrow: $next,
				asNavFor: $slider_nav,
				responsive: [
					{
						breakpoint: 991,
							settings: {
							vertical: false,

						}
					},
					{
						breakpoint: 470,
							settings: {
							vertical: false,
							dots: true
						}
					},
				]

			});

			$slider_nav.slick({
				slidesToShow: 5,
				vertical: true,
				verticalSwiping: true,
				arrows: false,
				infinite: true,
				// slidesToScroll: 1,

				asNavFor: $slick_slider,
				dots: false,
				centerMode: true,
				focusOnSelect: true,
				adaptiveHeight: true,
				responsive: [
					{
						breakpoint: 1400,
							settings: {
							// dots: true,
							arrows: false,
							slidesToShow: 3,
							vertical: false,
							centerMode: false,
							verticalSwiping: false,
							focusOnSelect: false,
							adaptiveHeight: false,
						}
					},
					{
						breakpoint: 1200,
							settings: {
						
							slidesToShow: 3,
						
						}
					},
					{
						breakpoint: 600,
							settings: {
						
							slidesToShow: 3,
							focusOnSelect: false,
							centerMode: false,
							adaptiveHeight: true,
						
						}
					},
					{
						breakpoint: 470,
							settings: {
							arrows: false,
							
							slidesToShow: 1,
							vertical: false,
							verticalSwiping: false,
							focusOnSelect: false,
							centerMode: false,

							adaptiveHeight: true,
						
						}
					},
					

				]
			  });

		});
	};

	



	 $.fn.alx_portfolio_slider = function() {
		$(this).each(function() {

			var $slider_nav = $(this).find('.alx-portfolio-slider__nav');

			var $slick_slider = $(this).find(".alx-portfolio-slider__slides").not('.slick-initialized');

			$slick_slider.slick({
				dots: false,
				fade: false,
				arrows: false,
				dotsClass: 'dots',
				autoplay: false,
				autoplaySpeed: 8000,
				autoHeight: false,
				infinite: true,
				// vertical: true,
				cssEase: 'linear',
				adaptiveHeight: true,
				asNavFor: $slider_nav,
				responsive: [
					{
						breakpoint: 992,
							settings: {
							arrows: false,
							// dots: true
						}
					},
				]
			});




			$slider_nav.slick({
				slidesToShow: 5,
				arrows: false,
				// infinite: true,
				slidesToScroll: 1,
				asNavFor: $slick_slider,
				dots: false,
				centerMode: true,
				focusOnSelect: true,
				responsive: [
					{
						breakpoint: 1400,
							settings: {
							slidesToShow: 3,
						}
					},

				]
			  });
		});
	};

	$('.alx-portfolio-slider').alx_portfolio_slider();


	/*-------------------------------------
	 	Back to top
	-------------------------------------*/
	$(function() {
        var backToTop = {
            element: $('.al-btn-to-top'),
            offset: 350,
            duration: 350
        };
        $(window).on('scroll', function() {
            if ($(this).scrollTop() > backToTop.offset) {
                backToTop.element.removeClass('is-hidden').addClass('is-visible');
            } else {
                backToTop.element.removeClass('is-visible').addClass('is-hidden');
            }
        });
        backToTop.element.on('click', function() {
            $('html, body').animate({
                scrollTop: 0
            }, backToTop.duration);
            return false;
        });
	});


	/*-------------------------------------
	Top nav
	-------------------------------------*/
	$(function(){
		// scroll is still position
		  var scroll = $(document).scrollTop(),
			  window_view = $(window),
			  $body = $('body'),
			  headerHeight = $('.page-header').outerHeight();

		  //console.log(headerHeight);

		/*-------------------------------------
		Top menu - fixed
		-------------------------------------*/
		window_view.on('scroll', function() {
			var winTop = window_view.scrollTop(),
				top_nav = $("#top-nav");

				if(winTop >= 150){
			top_nav.addClass("is-sticky");
			}else{
				top_nav.removeClass("is-sticky");
			}
			/*-------------------------------------
			Back to top link
			-------------------------------------*/
			  $(function(){
				  var y = $(this).scrollTop(),
					  top = $('.top');
				  if (y > 1000) {
					  top.fadeIn('slow');
				  } else {
					  top.fadeOut('slow');
				  }
			  });

			  /*-------------------------------------
			  Hide Header on on scroll down
			  -------------------------------------*/
			  $(function(){
				  // scrolled is new position just obtained
				  var scrolled = $(document).scrollTop(),
					  page_header = $('.page-header');


					  if (scrolled > headerHeight){
						  page_header.addClass('off-canvas-menu');
					  } else {
						  page_header.removeClass('off-canvas-menu');
					  }

					  if (scrolled > scroll){
						   // scrolling down
						   page_header.removeClass('fixed-tp-menu');
						  $body.removeClass('al-admin-off-menu');
						} else {
							//scrolling up
							page_header.addClass('fixed-tp-menu');
							$body.addClass('al-admin-off-menu');
					  }

					  scroll = $(document).scrollTop();
				  });
			  })
	  });



	/*-------------------------------------
	 	Tilt
	 -------------------------------------*/
	// $('.al-tilt, .al-play-video').tilt();

	/*-------------------------------------
	 	MatchHeight
	 -------------------------------------*/
	 $('.al-inslider-item').matchHeight({
        property: 'height'
	});



	/*-------------------------------------
	Mailchimp subscribe form processing
	-------------------------------------*/
	$('#alx-subscribe-form').on('submit', function( e ) {
		e.preventDefault();
		// update user interface
		$('#response').html('Adding email address...');

		// Prepare query string and send AJAX request
		jQuery.ajax({
			url: 'mailchimp/store-address.php',
			data: 'ajax=true&email=' + escape($('#mailchimp_email').val()),
			success: function(msg) {
				$('#response').html(msg);
				$('#response').slideToggle('slow');
			}
		});
	});

	/*-------------------------------------
		Google maps API
	-------------------------------------*/
	if (typeof $.fn.gmap3 !== 'undefined') {

		$(".alx-map").each(function() {

			var data_zoom = 15,
				data_height;

			if ($(this).attr("data-zoom") !== undefined) {
				data_zoom = parseInt($(this).attr("data-zoom"),10);
			}
			if ($(this).attr("data-height") !== undefined) {
				data_height = parseInt($(this).attr("data-height"),10);
			}


			$(this).gmap3({

				marker: {
					values: [{
						address: $(this).attr("data-address"),
						data: $(this).attr("data-address-details")
					}],
					options:{
						draggable: false,
						icon: $(this).attr("data-marker")
					},
					events:{
						mouseover: function(marker, event, context){
							var map = $(this).gmap3("get"),
							infowindow = $(this).gmap3({get:{name:"infowindow"}});
							if (infowindow){
								infowindow.open(map, marker);
								infowindow.setContent(context.data);
							} else {
								$(this).gmap3({
									infowindow:{
										anchor:marker,
										options:{content: context.data}
									}
								});
							}
						},
						mouseout: function(){
							var infowindow = $(this).gmap3({get:{name:"infowindow"}});
							if (infowindow){
								infowindow.close();
							}
						}
					}
				},
				map: {
					options: {
						mapTypeId: google.maps.MapTypeId.ROADMAP,
						zoom: data_zoom,
						scrollwheel: false,
						styles: [{"featureType":"administrative","elementType":"all","stylers":[{"saturation":"-100"}]},{"featureType":"administrative.province","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"landscape","elementType":"all","stylers":[{"saturation":-100},{"lightness":65},{"visibility":"on"}]},{"featureType":"poi","elementType":"all","stylers":[{"saturation":-100},{"lightness":"50"},{"visibility":"simplified"}]},{"featureType":"road","elementType":"all","stylers":[{"saturation":"-100"}]},{"featureType":"road.highway","elementType":"all","stylers":[{"visibility":"simplified"}]},{"featureType":"road.arterial","elementType":"all","stylers":[{"lightness":"30"}]},{"featureType":"road.local","elementType":"all","stylers":[{"lightness":"40"}]},{"featureType":"transit","elementType":"all","stylers":[{"saturation":-100},{"visibility":"simplified"}]},{"featureType":"water","elementType":"geometry","stylers":[{"hue":"#ffff00"},{"lightness":-25},{"saturation":-97}]},{"featureType":"water","elementType":"labels","stylers":[{"lightness":-25},{"saturation":-100}]}]
					}
				}
			});
			$(this).css("height", data_height + "px");
		});

	}


	/*-------------------------------------
		Price Tabs
	-------------------------------------*/

	// $(".al-price-table").animated("fadeIn");

	/*-------------------------------------
		PlayBTN
	-------------------------------------*/
	$('.al-play-video__button').magnificPopup({
		type: 'iframe',
		autoFocusLast: false,
		mainClass: 'mfp-with-zoom',
		iframe: {
			markup: '<div class="mfp-iframe-scaler">'+
			'<div class="mfp-close"></div>'+
			'<iframe class="mfp-iframe" frameborder="0" allowfullscreen></iframe>'+
			'</div>', // HTML markup of popup, `mfp-close` will be replaced by the close button

			patterns: {
				youtube: {
					index: 'youtube.com/', // String that detects type of video (in this case YouTube). Simply via url.indexOf(index).
					id: 'v=', // String that splits URL in a two parts, second part should be %id%
						// Or null - full URL will be returned
						// Or a function that should return %id%, for example:
						// id: function(url) { return 'parsed id'; }
					src: '//www.youtube.com/embed/%id%?autoplay=1' // URL that will be set as a source for iframe.
				},

				vimeo: {
					index: 'vimeo.com/',
					id: '/',
					src: '//player.vimeo.com/video/%id%?autoplay=1'
				},

				gmaps: {
					index: '//maps.google.',
					src: '%id%&output=embed'
				}

			},
			zoom: {
				enabled: true, // By default it's false, so don't forget to enable it

				duration: 300, // duration of the effect, in milliseconds
				easing: 'ease-in-out', // CSS transition easing function

				// The "opener" function should return the element from which popup will be zoomed in
				// and to which popup will be scaled down
				// By defailt it looks for an image tag:
				opener: function(openerElement) {
					// openerElement is the element on which popup was initialized, in this case its <a> tag
					// you don't need to add "opener" option if this code matches your needs, it's defailt one.
					return openerElement.is('img') ? openerElement : openerElement.find('img');
					}
			},

			srcAction: 'iframe_src', // Templating object key. First part defines CSS selector, second attribute. "iframe_src" means: find "iframe" and set attribute "src".
		}
	});




	/*-------------------------------------
		E-mail Ajax Send
	-------------------------------------*/
	$('.alx-contact-form').on('submit',function() {
		var th = $(this);
		$.ajax({
			type: "POST",
			url: "mail.php", //Change
			data: th.serialize()
		}).done(function() {
			th.trigger("reset");
			th.find('.alx-success').slideToggle('slow');
			setTimeout(function() {
				// Done Functions
				th.find('.alx-success').slideToggle('hide');
			}, 3000);
		});
		return false;
	});


	/*-------------------------------------
		Drag images restagt
	-------------------------------------*/
	$('img, a').on('dragstart', function(event) { event.preventDefault(); });

		/*-------------------------------------
		Smooth Scroll to link

	 , .al-no-click, .image-modal
	-------------------------------------*/

    $(document).on('click', 'a[href^="#"]', function(e) {

        var id = $(this).attr('href');
        // target element
        var $id = $(id);
        if ($id.length === 0) {
            return;
        }
        if($(this).is('.al-no-click, .image-modal, .ui-tabs-anchor')){
        	console.log('has');
		}else{
            if($('.single-product').length === 0){
                e.preventDefault();
                var pos = $id.offset().top;
                $('html, body').stop().animate({
                    scrollTop: pos
                }, {
                    duration: 1000,
                    specialEasing: {
                        width: "linear",
                        height: "easeInOutCubic"
                    }
                });
            }
		}
	});

	

	


	


	
	/*-------------------------------------
		Animations
	-------------------------------------*/
	$(function () {
		if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
			} else {
				// $(".al-heading > .al-heading__title").animated("fadeInDown");
				// $(".al-heading > .al-heading__description").animated("fadeInUp");
				// $(".al-team").animated("fadeIn");
				// $(".al-faq__title").animated("fadeInUp");
				// $(".al-contact, .al-service-item").animated("zoomIn");
				// $(".al-contact-map").animated("fadeInDown");
			}
	}());

	/*-------------------------------------
		Into slider
	-------------------------------------*/
	$(function() {
		var introHeader = $('.alx-intro'),
			window_view = $(window),
			intro = $('.alx-intro');

		buildModuleHeader(introHeader);

		window_view.resize(function() {
			var width = Math.max(window_view.width(), window_view.innerWidth);
			buildModuleHeader(introHeader);
		});

		window_view.scroll(function() {
			effectsModuleHeader(introHeader, this);
		});

		function buildModuleHeader(introHeader) {
		};
		function effectsModuleHeader(introHeader, scrollTopp) {
			if (introHeader.length > 0) {
				var homeSHeight = introHeader.height();
				var topScroll = $(document).scrollTop();
				if ((introHeader.hasClass('al-intro')) && ($(scrollTopp).scrollTop() <= homeSHeight)) {
					// introHeader.css('top', (topScroll * .4));
				}
				if (introHeader.hasClass('al-intro') && ($(scrollTopp).scrollTop() <= homeSHeight)) {
					introHeader.css('opacity', (1 - topScroll/introHeader.height() * 1));
				}
			}
		};
	});

});
